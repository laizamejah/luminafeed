import { createFileRoute, Link } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { formatDistanceToNow } from "date-fns";
import { fetchFeed } from "@/lib/feed";
import { PostCard } from "@/components/post-card";
import { PostComposer } from "@/components/post-composer";
import { StoriesBar } from "@/components/stories-bar";
import { SuggestedFriends } from "@/components/suggested-friends";
import { Button } from "@/components/ui/button";

import { useCurrentUser, useCurrentProfile } from "@/hooks/use-current-user";
import { AvatarImage } from "@/components/avatar-image";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

export const Route = createFileRoute("/_authenticated/feed")({
  component: FeedPage,
});

function FeedPage() {
  const { data: user } = useCurrentUser();
  const { data: me } = useCurrentProfile();
  const hideReels = me?.hide_reels ?? false;
  const kidOnly = me?.is_kid ?? false;

  const qc = useQueryClient();

  const { data: posts, isLoading } = useQuery({
    queryKey: ["feed", user?.id ?? null, hideReels, kidOnly],
    queryFn: () => fetchFeed(user?.id ?? null, hideReels, kidOnly),
  });

  const { data: friendRequests = [], isLoading: friendRequestsLoading } = useQuery({
    queryKey: ["friend-requests", me?.id],
    enabled: !!me,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("friend_requests")
        .select("id, sender_id, status, created_at, sender:profiles!friend_requests_sender_id_fkey(id, username, display_name, avatar_url)")
        .eq("recipient_id", me!.id)
        .eq("status", "pending")
        .order("created_at", { ascending: false })
        .limit(6);
      if (error) throw error;
      return data ?? [];
    },
    staleTime: 30_000,
  });

  const { data: recentNotifications = [] } = useQuery({
    queryKey: ["feed-notifications", me?.id],
    enabled: !!me,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("notifications")
        .select("id, actor_id, type, data, read_at, created_at, actor:profiles!notifications_actor_id_fkey(id, username, display_name, avatar_url)")
        .eq("user_id", me!.id)
        .order("created_at", { ascending: false })
        .limit(4);
      if (error) throw error;
      return data ?? [];
    },
    staleTime: 30_000,
  });

  const respondToRequest = useMutation({
    mutationFn: async ({ requestId, senderId, accept }: { requestId: string; senderId: string; accept: boolean }) => {
      const { error } = await supabase
        .from("friend_requests")
        .update({ status: accept ? "accepted" : "declined" })
        .eq("id", requestId);
      if (error) throw error;

      if (accept) {
        await supabase.from("follows").upsert([
          { follower_id: me!.id, following_id: senderId, tier: "acquaintance" },
          { follower_id: senderId, following_id: me!.id, tier: "acquaintance" },
        ]);
        await supabase.from("notifications").insert({
          user_id: senderId,
          actor_id: me!.id,
          type: "friend_accepted",
          data: { username: me!.username },
        });
      }
    },
    onSuccess: () => {
      toast.success("Friend request updated");
      qc.invalidateQueries({ queryKey: ["friend-requests", me?.id] });
      qc.invalidateQueries({ queryKey: ["feed-notifications", me?.id] });
      qc.invalidateQueries({ queryKey: ["notifications", me?.id] });
    },
    onError: (error) => {
      toast.error(error instanceof Error ? error.message : "Unable to update request");
    },
  });

  const requestCount = friendRequests.length;

  return (
    <div className="mx-auto w-full max-w-[1400px] px-4 sm:px-6 lg:px-8 py-8">
      <div className="lg:grid lg:grid-cols-[minmax(0,1fr)_280px] lg:items-start lg:gap-8">
        <div className="flex-1 w-full max-w-[680px] mx-auto lg:mx-0">
          <div className="sticky top-0 z-10 bg-background/85 backdrop-blur border-b border-border">
            <div className="hidden md:flex items-baseline justify-between px-4 py-6">
              <h1 className="font-serif text-3xl">Feed</h1>
              <span className="text-xs text-muted-foreground">Chronological · no algorithm</span>
            </div>
          </div>

          {me && (
            <PostComposer />
          )}

          <StoriesBar />

          {isLoading && (
            <div className="space-y-8 p-4">
              {[0, 1].map((i) => (
                <div key={i} className="space-y-3">
                  <div className="flex items-center gap-3">
                    <div className="h-10 w-10 rounded-full bg-muted animate-pulse" />
                    <div className="h-4 w-32 bg-muted rounded animate-pulse" />
                  </div>
                  <div className="aspect-[4/5] w-full bg-muted rounded animate-pulse" />
                </div>
              ))}
            </div>
          )}

          {!isLoading && posts?.length === 0 && (
            <div className="p-12 text-center">
              <p className="font-serif text-xl">Nothing here yet.</p>
              <p className="mt-2 text-sm text-muted-foreground">Share your first frame.</p>
            </div>
          )}

          <div className="space-y-6">
            {posts?.map((p, i) => (
              <div key={p.id}>
                <PostCard post={p} />
                {i === 2 && <SuggestedFriends />}
              </div>
            ))}
            {!isLoading && (posts?.length ?? 0) <= 2 && <SuggestedFriends />}
          </div>
        </div>

        <aside className="hidden lg:sticky lg:top-6 lg:block w-[280px] shrink-0 overflow-y-auto">
          <div className="space-y-6">
            <div className="rounded-3xl border border-border/50 bg-card p-5 shadow-lg shadow-black/10">
              <div className="flex items-center justify-between gap-3">
                <div>
                  <h2 className="text-lg font-semibold">Follow Requests</h2>
                  <p className="text-sm text-muted-foreground">Approve your incoming connections</p>
                </div>
                <span className="rounded-full bg-white/5 px-2 py-1 text-[11px] uppercase tracking-[0.18em] text-muted-foreground">
                  {requestCount} pending
                </span>
              </div>

              <div className="mt-5 space-y-4">
                {friendRequestsLoading ? (
                  Array.from({ length: 3 }).map((_, index) => (
                    <div key={index} className="animate-pulse rounded-3xl border border-border/50 bg-background/80 p-4">
                      <div className="flex items-center gap-3">
                        <div className="h-10 w-10 rounded-full bg-muted" />
                        <div className="space-y-2 flex-1">
                          <div className="h-3 w-24 rounded bg-muted" />
                          <div className="h-3 w-32 rounded bg-muted" />
                        </div>
                      </div>
                    </div>
                  ))
                ) : friendRequests.length === 0 ? (
                  <div className="rounded-3xl border border-border/50 bg-background/80 p-4 text-sm text-muted-foreground">
                    All caught up. No new request activity right now.
                  </div>
                ) : (
                  friendRequests.map((request) => {
                    const sender = request.sender;
                    const senderName = sender?.display_name ?? sender?.username ?? "Someone";
                    return (
                      <div key={request.id} className="rounded-3xl border border-border/50 bg-background/80 p-4">
                        <div className="flex items-center gap-3">
                          <AvatarImage path={sender?.avatar_url} name={senderName} size={40} />
                          <div className="min-w-0 flex-1">
                            <p className="truncate font-medium">{senderName}</p>
                            <p className="truncate text-xs text-muted-foreground">@{sender?.username}</p>
                            <p className="mt-2 text-xs text-muted-foreground">
                              Requested {formatDistanceToNow(new Date(request.created_at), { addSuffix: true })}
                            </p>
                          </div>
                        </div>
                        <div className="mt-4 flex gap-2">
                          <Button
                            size="sm"
                            className="flex-1"
                            onClick={() => respondToRequest.mutate({ requestId: request.id, senderId: request.sender_id, accept: true })}
                            disabled={respondToRequest.isPending}
                          >
                            Accept
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            className="flex-1"
                            onClick={() => respondToRequest.mutate({ requestId: request.id, senderId: request.sender_id, accept: false })}
                            disabled={respondToRequest.isPending}
                          >
                            Decline
                          </Button>
                        </div>
                      </div>
                    );
                  })
                )}
              </div>

              <div className="mt-6 border-t border-border/50 pt-4 text-right">
                <Link to="/notifications" className="text-sm font-medium text-primary hover:underline">
                  View all requests
                </Link>
              </div>
            </div>

            <div className="rounded-3xl border border-border/50 bg-card p-5 shadow-lg shadow-black/10">
              <div className="flex items-center justify-between gap-3">
                <div>
                  <h2 className="text-lg font-semibold">Activity & Reminders</h2>
                  <p className="text-sm text-muted-foreground">Recent updates from your network</p>
                </div>
                <Link to="/notifications" className="text-xs uppercase tracking-[0.18em] text-muted-foreground hover:text-foreground">
                  See all
                </Link>
              </div>

              <div className="mt-5 space-y-3">
                {recentNotifications.length === 0 ? (
                  <div className="rounded-3xl border border-border/50 bg-background/80 p-4 text-sm text-muted-foreground">
                    No new notifications. Keep posting to stay connected.
                  </div>
                ) : (
                  recentNotifications.map((notification) => {
                    const actor = notification.actor;
                    const actorName = actor?.display_name ?? actor?.username ?? "Someone";
                    const description =
                      notification.type === "friend_request"
                        ? "sent you a friend request"
                        : notification.type === "friend_accepted"
                        ? "accepted your request"
                        : notification.type === "like"
                        ? "liked your post"
                        : notification.type === "comment"
                        ? `commented: ${typeof notification.data?.text === "string" ? notification.data.text : "your post"}`
                        : notification.type === "new_post"
                        ? "shared a new post"
                        : notification.type === "new_story"
                        ? "posted a new story"
                        : notification.type;

                    return (
                      <Link
                        key={notification.id}
                        to="/notifications"
                        className="block rounded-3xl border border-border/50 bg-background/80 p-4 hover:border-primary/40 hover:bg-white/5"
                      >
                        <div className="flex items-center gap-3">
                          <AvatarImage path={actor?.avatar_url} name={actorName} size={36} />
                          <div className="min-w-0 flex-1">
                            <p className="truncate text-sm font-medium">{actorName}</p>
                            <p className="truncate text-xs text-muted-foreground">{description}</p>
                          </div>
                        </div>
                        <p className="mt-3 text-[11px] uppercase tracking-[0.16em] text-muted-foreground">
                          {formatDistanceToNow(new Date(notification.created_at), { addSuffix: true })}
                        </p>
                      </Link>
                    );
                  })
                )}
              </div>
            </div>
          </div>
        </aside>
      </div>
    </div>
  );
}
