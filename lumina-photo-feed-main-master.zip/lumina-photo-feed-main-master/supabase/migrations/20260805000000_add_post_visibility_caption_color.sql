ALTER TYPE public.follow_tier ADD VALUE IF NOT EXISTS 'close_friend';

DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'post_visibility') THEN
    CREATE TYPE public.post_visibility AS ENUM ('public', 'friends', 'private');
  END IF;
END$$;

ALTER TABLE public.posts
  ADD COLUMN IF NOT EXISTS caption_color TEXT,
  ADD COLUMN IF NOT EXISTS visibility public.post_visibility NOT NULL DEFAULT 'public';
