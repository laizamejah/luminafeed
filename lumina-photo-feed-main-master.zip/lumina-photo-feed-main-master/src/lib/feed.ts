import { supabase } from "@/integrations/supabase/client";
import type { FeedPost } from "@/components/post-card";

const SELECT = `
  id, caption, caption_color, visibility, created_at, latitude, longitude, location_name,
  comments_enabled, is_reel, user_id,
  audio_preview_url, audio_title, audio_artist, audio_artwork_url,
  author:profiles!posts_user_id_fkey (id, username, display_name, avatar_url, show_metrics_publicly),
  media:post_media (id, storage_path, media_type, width, height, thumbnail_path, position)
`;

const FRIEND_FOLLOW_TIERS = ["acquaintance", "close_friend"] as const;

async function fetchFriendIds(userId: string) {
  const { data, error } = await supabase
    .from("follows")
    .select("following_id")
    .in("tier", FRIEND_FOLLOW_TIERS)
    .eq("follower_id", userId);
  if (error) throw error;
  return (data ?? []).map((row) => row.following_id as string);
}

export async function fetchFeed(userId: string | null, hideReels: boolean, kidOnly = false): Promise<FeedPost[]> {
  const friendIds = userId ? await fetchFriendIds(userId) : [];

  let query = supabase
    .from("posts")
    .select(SELECT)
    .order("created_at", { ascending: false })
    .limit(80);

  if (hideReels) query = query.eq("is_reel", false);
  if (kidOnly) query = query.eq("kid_safe", true);

  if (!userId) {
    query = query.eq("visibility", "public");
  } else {
    const clauses = [
      `visibility.eq.public`,
      `user_id.eq.${userId}`,
    ];

    if (friendIds.length > 0) {
      const quotedIds = friendIds.map((id) => `"${id}"`).join(",");
      clauses.push(`and(visibility.eq.friends,user_id.in.(${quotedIds}))`);
    }

    query = query.or(clauses.join(","));
  }

  const { data, error } = await query;
  if (error) throw error;
  return (data ?? []) as unknown as FeedPost[];
}

export async function fetchGeoPosts(): Promise<FeedPost[]> {
  const { data, error } = await supabase
    .from("posts")
    .select(SELECT)
    .not("latitude", "is", null)
    .not("longitude", "is", null)
    .order("created_at", { ascending: false })
    .limit(500);
  if (error) throw error;
  return (data ?? []) as unknown as FeedPost[];
}
